# HTML & CSS Lab — Fundamentos da Web

Projeto acadêmico desenvolvido para demonstrar, de forma visual e responsiva, conceitos fundamentais de HTML5 e CSS3.

## Conteúdos demonstrados

- **HTML5 semântico:** uso de `header`, `nav`, `main`, `section`, `article` e `footer`.
- **Identificadores (`id`):** seleção de um elemento específico por meio de `#`.
- **Classes (`class`):** reaproveitamento de estilos por meio de `.`.
- **Box Model:** conteúdo, `padding`, `border` e `margin`.
- **Elementos block e inline:** exemplos com `div`, `p`, `section`, `span`, `a` e `strong`.
- **CSS responsivo:** ajustes para diferentes tamanhos de tela com media queries.
- **Acessibilidade básica:** idioma da página, rótulos de navegação e link para pular ao conteúdo.

## Como abrir

1. Extraia os arquivos para uma pasta.
2. Abra a pasta no Visual Studio Code.
3. Abra `index.html` no navegador. Também é possível usar a extensão Live Server.
4. O arquivo `style.css` contém os estilos da página.

## Estrutura dos arquivos

- `index.html` — conteúdo e estrutura semântica.
- `style.css` — apresentação visual, seletores e responsividade.
- `README.md` — descrição e instruções do projeto.

## Observação acadêmica

Leia os exemplos e pratique alterar valores de CSS, como `padding`, `margin`, `border` e `display`, para observar como a página se comporta.
